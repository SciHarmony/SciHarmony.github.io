
async function loadJSON(path){
  try{
    const res = await fetch(path);
    if(!res.ok) return null;
    return await res.json();
  }catch(e){ return null; }
}
async function renderImpact(){
  const el = document.querySelector('#impact-counters');
  if(!el) return;
  const data = await loadJSON('data/impact.json');
  if(!data) return;
  const items = [
    ['Students served', data.students_served],
    ['Contact hours', data.contact_hours],
    ['Volunteers trained', data.volunteers_trained],
    ['Sessions run', data.sessions_run],
    ['Interest gain', (data.percent_interest_gain*100).toFixed(0)+'%']
  ];
  el.innerHTML = items.map(([k,v])=>`<div class="kpi"><div class="kpi-num"><strong>${v}</strong></div><div>${k}</div></div>`).join('');
}
document.addEventListener('DOMContentLoaded', renderImpact);
